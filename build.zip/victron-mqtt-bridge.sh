#!/bin/sh
while true; do
  /data/victron-mqtt-bridge
  sleep 5
done